﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Service
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void crear_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (ServiceReference1.Service2Client cliente = new ServiceReference1.Service2Client())
                {
                    cliente.crear(Int32.Parse(clave.Text), categoria.Text, material.Text, float.Parse(precio.Text), proveedor.Text, clientes.Text );
                    MessageBox.Show("El producto ha sido registrado en la BD de Platina");
                }
                clave.Text = "";
                categoria.Text = "";
                material.Text = "";
                precio.Text = "";
                proveedor.Text = "";
                clientes.Text = "";
            }
            catch
            {
                MessageBox.Show("Ingrese datos para registrar el producto en la BD de Platina");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void buscar_Click(object sender, RoutedEventArgs e)
        {
            string[] vector = new string[6];
            using (ServiceReference1.Service2Client cliente = new ServiceReference1.Service2Client())
            {
                try
                {
                    vector = cliente.buscar(Convert.ToInt32(clave.Text));
                    if (vector[0] == null)
                    {
                        MessageBox.Show("No hay un registro con la clave indicada dentro de la BD de Platina");
                    }
                        categoria.Text = vector[1];
                        material.Text = vector[2];
                        precio.Text = vector[3];
                        proveedor.Text = vector[4];
                        clientes.Text = vector[5];
                   
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ingrese la clave del producto que desea buscar en la BD de Platina");
                }
            }
        }

        private void modificar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (ServiceReference1.Service2Client cliente = new ServiceReference1.Service2Client())
                {
                    if (cliente.modificar(Int32.Parse(clave.Text), categoria.Text, material.Text, float.Parse(precio.Text), proveedor.Text, clientes.Text))
                    {
                        MessageBox.Show("Los datos del regitro de la BD de Platina han sido modificados");
                    }
                    else
                    {
                        MessageBox.Show("Los datos del regirto de la BD no han sido modificados");
                    }
                }
                clave.Text = "";
                categoria.Text = "";
                material.Text = "";
                precio.Text = "";
                proveedor.Text = "";
                clientes.Text = "";
            }
            catch
            {
                MessageBox.Show("Busque el registro dentro de la BD de Platina que desea modificar");
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            using (ServiceReference1.Service2Client cliente = new ServiceReference1.Service2Client())
            {
                try
                {
                    if (cliente.eliminar(Int32.Parse(clave.Text)))
                    {
                        MessageBox.Show("El registro de la BD de Platina han sido eliminados");
                    }
                    else
                    {
                        MessageBox.Show("El registro no existe en la BD de Platina ");
                    }
                }
                catch
                {
                    MessageBox.Show("Busque el registro que desea eliminar dentro de la BD de Platina");
                }
            }
            clave.Text = "";
            categoria.Text = "";
            material.Text = "";
            precio.Text = "";
            proveedor.Text = "";
            clientes.Text = "";
            
        }
    }
}
