﻿namespace MaterialDesignThemes.Wpf
{
    public enum BaseTheme
    {
        Inherit,
        Light,
        Dark
    }
}
